<?php
session_start();

// initializing variables'
$fname = "fname";
$lname = "lname";
$email    = "email";
$profession = "profession";
$phone = "phone";
$msg="msg";
$interest="interest";



// connect to the database
$db = mysqli_connect('localhost','root','','contact');

// REGISTER USER
if (isset($_POST['reg_user']))
 {
  // receive all input values from the form
  $fname= mysqli_real_escape_string($db, $_POST['fname']);
  // $lname= mysqli_real_escape_string($db, $_POST['lname']);
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $phone = mysqli_real_escape_string($db, $_POST['phone']);
  $profession = mysqli_real_escape_string($db, $_POST['profession']);
  
  $interest = mysqli_real_escape_string($db, $_POST['interest']);

  $msg= mysqli_real_escape_string($db, $_POST['msg']);
  
  
  if (1==1)
  {
   

    $query = "INSERT INTO users (fname,email,phone,msg,profession,interest) 
          VALUES('$fname','$email','$phone','$msg','$profession','$interest)";
    mysqli_query($db, $query);
    $_SESSION['fname'] = $fname;
    $_SESSION['success'] = "You are now logged in";
    $K=1;
    
    

  }
  else {
    $K=2;
  }
  if($k==1) {
    
    header('location: welcome.html');
  }
}

  // Finally, register user if there are no errors in the form
   }
if (isset($_POST['login_user']))
 {
  $email = mysqli_real_escape_string($db, $_POST['email']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($email)) {
    array_push($errors, "Email is required");  }
  if (empty($password)) {
    array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
    $password = md5($password);
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
  
    $results = mysqli_query($db, $query);
    if (mysqli_num_rows($results) == 1) {
      $_SESSION['email'] = $email;
      $_SESSION['success'] = "You are now logged in";
      header('location:  invoice/index.html');
    }else {
      array_push($errors, "Wrong username/password combination");
    }
  }
}
?>