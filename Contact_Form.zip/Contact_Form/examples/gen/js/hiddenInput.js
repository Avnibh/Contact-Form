$("#phone").intlTelInput({
  hiddenInput: "full_phone",
  utilsScript: "../../build/js/utils.js?1535108287294" // just for formatting/placeholders etc
});
